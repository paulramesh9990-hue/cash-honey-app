import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Target, TrendingUp, PieChart, Shield, Award, 
  Plus, ArrowRight, Zap, Lock, User 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Types
interface Goal {
  id: number;
  name: string;
  target: number;
  current: number;
  deadline: string;
  xp: number;
}

interface BudgetCategory {
  name: string;
  budget: number;
  spent: number;
}

interface Investment {
  id: number;
  name: string;
  allocation: number;
  return: number;
  risk: string;
}

interface Insight {
  id: number;
  title: string;
  description: string;
  impact: string;
  action: string;
}

interface UserProfile {
  name: string;
  joinDate: string;
}

// Professional AI Insights Generator
const generateAIInsights = (budgets: BudgetCategory[], goals: Goal[]): Insight[] => {
  const insights: Insight[] = [];
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const totalBudget = budgets.reduce((sum, b) => sum + b.budget, 0);
  
  budgets.forEach(cat => {
    if (cat.budget > 0 && cat.spent > cat.budget * 0.85) {
      insights.push({
        id: Date.now() + Math.random(),
        title: `${cat.name} Approaching Limit`,
        description: `ML model detected spending at ${Math.round((cat.spent / cat.budget) * 100)}% of allocated budget.`,
        impact: `Potential overspend of $${Math.round(cat.spent - cat.budget * 0.85)}`,
        action: 'Adjust allocation'
      });
    }
  });

  const completedGoals = goals.filter(g => g.current >= g.target).length;
  if (completedGoals > 0) {
    insights.push({
      id: Date.now(),
      title: "Goal Achievement Pattern",
      description: "Strong goal completion rate detected. Your consistency indicates high financial discipline.",
      impact: `+${completedGoals * 120} XP earned`,
      action: "Set next milestone"
    });
  }

  if (totalSpent > 0 && totalSpent < totalBudget * 0.6) {
    insights.push({
      id: Date.now() + 1,
      title: "Excellent Spending Control",
      description: "Your spending behavior shows disciplined control aligned with long-term objectives.",
      impact: "Strong trajectory",
      action: "Continue current plan"
    });
  }

  return insights.length > 0 ? insights : [{
    id: 999,
    title: "Begin Tracking",
    description: "Add transactions and goals to receive personalized ML-driven insights.",
    impact: "Data required",
    action: "Start adding data"
  }];
};

const Sidebar: React.FC = () => {
  const location = useLocation();
  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/budget', label: 'Smart Budget', icon: PieChart },
    { path: '/investments', label: 'AI Investments', icon: TrendingUp },
    { path: '/goals', label: 'Goals & Rewards', icon: Target },
    { path: '/insights', label: 'ML Insights', icon: Zap },
    { path: '/security', label: 'Security & Privacy', icon: Shield },
  ];

  return (
    <div className="w-72 bg-[#0A0F1E] border-r border-white/10 h-screen fixed left-0 top-0 z-50 flex flex-col">
      <div className="p-8">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-9 h-9 bg-[#0A84FF] rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-2xl tracking-[-1.5px]">A</span>
          </div>
          <div>
            <div className="font-semibold text-2xl tracking-[-1px]">AFP</div>
            <div className="text-[10px] text-white/50 -mt-1">FINANCE AI</div>
          </div>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link 
                key={item.path} 
                to={item.path}
                className={`flex items-center gap-3.5 px-5 py-3.5 rounded-2xl text-sm font-medium transition-all ${isActive 
                  ? 'bg-white/10 text-white' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Icon size={19} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-8 border-t border-white/10">
        <div className="flex items-center gap-3 text-sm">
          <div className="w-8 h-8 bg-white/10 rounded-full overflow-hidden">
            <img src="/images/user.jpg" alt="Profile" className="object-cover" />
          </div>
          <div>
            <div className="font-medium text-sm">Elena Vasquez</div>
            <div className="text-[10px] text-white/50">Premium Member • Level 14</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC<{ 
  budgets: BudgetCategory[]; 
  goals: Goal[]; 
  investments: Investment[];
  totalNetWorth: number;
}> = ({ budgets, goals, investments, totalNetWorth }) => {
  const totalBudget = budgets.reduce((sum, b) => sum + b.budget, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const savingsRate = Math.round(((totalBudget - totalSpent) / totalBudget) * 100);

  return (
    <div className="ml-72 p-10 max-w-7xl">
      <div className="flex justify-between items-end mb-10">
        <div>
          <div className="text-[#0A84FF] text-sm font-medium tracking-[3px]">WELCOME BACK, ELENA</div>
          <h1 className="text-6xl font-semibold tracking-[-2.5px] mt-1">Your finances,<br />intelligently managed.</h1>
        </div>
        <div className="text-right">
          <div className="text-xs uppercase tracking-[2px] text-white/50">NET WORTH</div>
          <div className="text-5xl font-semibold tabular-nums tracking-[-1.5px] mt-1">${totalNetWorth.toLocaleString()}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="finance-card rounded-3xl p-7">
          <div className="flex justify-between mb-8">
            <div><div className="text-white/60 text-sm">Monthly Savings Rate</div><div className="text-5xl font-semibold mt-1 tracking-tight">{savingsRate}%</div></div>
            <div className="text-[#22C55E]"><TrendingUp size={38} /></div>
          </div>
          <div className="h-1.5 bg-white/10 rounded-full"><div className="h-1.5 bg-[#22C55E] rounded-full" style={{width: `${savingsRate}%`}} /></div>
        </div>

        <div className="finance-card rounded-3xl p-7">
          <div className="text-white/60 text-sm mb-1">Active Goals Progress</div>
          <div className="text-5xl font-semibold tabular-nums tracking-tight">{Math.round(goals.reduce((a, g) => a + (g.current/g.target), 0) / goals.length * 100)}%</div>
          <div className="mt-4 text-sm text-white/50">3 goals on track • 1,880 XP earned this month</div>
        </div>

        <div className="finance-card rounded-3xl p-7 flex flex-col justify-between">
          <div>
            <div className="text-white/60 text-sm">AI Portfolio Return</div>
            <div className="text-5xl font-semibold tracking-[-1.5px] mt-1">+14.8%</div>
          </div>
          <div className="text-[#0A84FF] flex items-center gap-2 text-sm font-medium cursor-pointer">View detailed forecast <ArrowRight size={16} /></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 finance-card rounded-3xl p-8">
          <div className="flex justify-between mb-6">
            <div className="font-semibold">Spending Breakdown</div>
            <div className="text-xs px-4 py-1 rounded-full bg-white/5 text-white/70">LIVE • UPDATED JUST NOW</div>
          </div>
          {budgets.map((cat, idx) => (
            <div key={idx} className="mb-5 last:mb-0">
              <div className="flex justify-between text-sm mb-2">
                <span>{cat.name}</span>
                <span className="font-mono tabular-nums">${cat.spent} <span className="text-white/40">/ ${cat.budget}</span></span>
              </div>
              <div className="h-2 bg-white/10 rounded"><div className="h-2 rounded bg-[#0A84FF]" style={{width: `${Math.min((cat.spent/cat.budget)*100,100)}%`}} /></div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-2 finance-card rounded-3xl p-8">
          <div className="font-semibold mb-5">Top Active Goals</div>
          {goals.slice(0,2).map(goal => {
            const progress = Math.round((goal.current / goal.target) * 100);
            return (
              <div key={goal.id} className="mb-7 last:mb-0">
                <div className="flex justify-between text-sm mb-2.5">
                  <span>{goal.name}</span><span className="font-mono">${goal.current}</span>
                </div>
                <div className="h-px bg-white/10 relative"><div className="absolute top-0 h-px bg-[#0A84FF]" style={{width: `${progress}%`}} /></div>
                <div className="flex justify-between text-xs mt-1.5 text-white/50"><div>{progress}% complete</div><div>Due {goal.deadline}</div></div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

const BudgetPage: React.FC<{ budgets: BudgetCategory[]; setBudgets: React.Dispatch<React.SetStateAction<BudgetCategory[]>> }> = ({ budgets, setBudgets }) => {
  const adjustBudget = (idx: number, delta: number) => {
    const updated = [...budgets];
    updated[idx].budget = Math.max(50, Math.min(5000, updated[idx].budget + delta));
    setBudgets(updated);
  };

  return (
    <div className="ml-72 p-10 max-w-5xl">
      <h2 className="text-5xl font-semibold tracking-[-2px] mb-3">Hyper-Personalized Budget</h2>
      <p className="text-white/60 mb-10 max-w-lg">Our adaptive ML engine continuously optimizes your allocations based on spending habits and goals.</p>

      <div className="grid gap-4">
        {budgets.map((cat, idx) => {
          const pct = Math.round((cat.spent / cat.budget) * 100);
          return (
            <div key={idx} className="finance-card rounded-3xl p-8 flex items-center gap-10">
              <div className="flex-1">
                <div className="flex justify-between mb-2">
                  <div className="font-semibold text-xl">{cat.name}</div>
                  <div className="font-mono text-2xl tracking-tight">${cat.budget}</div>
                </div>
                <div className="text-sm text-white/60">Spent: ${cat.spent} ({pct}%)</div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => adjustBudget(idx, -50)} className="px-6 py-2 rounded-2xl border border-white/20 hover:bg-white/5 active:bg-white/10 transition">- $50</button>
                <button onClick={() => adjustBudget(idx, 50)} className="px-6 py-2 rounded-2xl bg-[#0A84FF] hover:bg-[#0070E6] active:bg-[#0059B8] transition">+ $50</button>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-8 text-xs text-center text-white/40">AI recommends keeping Entertainment under $260 to hit your vacation goal 3 weeks early.</div>
    </div>
  );
};

const InvestmentsPage: React.FC<{ investments: Investment[]; setInvestments: React.Dispatch<React.SetStateAction<Investment[]>> }> = ({ investments, setInvestments }) => {
  const rebalance = () => {
    const newInv = investments.map(inv => ({
      ...inv,
      allocation: Math.max(8, Math.floor(inv.allocation + (Math.random() - 0.5) * 7))
    }));
    setInvestments(newInv);
  };

  const avgReturn = investments.reduce((sum, i) => sum + i.return * i.allocation, 0) / 100;

  return (
    <div className="ml-72 p-10 max-w-5xl">
      <div className="flex justify-between mb-8 items-end">
        <div>
          <h2 className="text-5xl font-semibold tracking-[-2px]">Proactive AI Investment Advice</h2>
          <p className="text-white/50 mt-3">Dynamic portfolio rebalanced in real-time by our open-banking integrated models</p>
        </div>
        <button onClick={rebalance} className="flex items-center px-7 py-3 bg-white text-black rounded-2xl text-sm font-medium active:bg-zinc-200">REBALANCE PORTFOLIO</button>
      </div>

      <div className="finance-card rounded-3xl p-9 mb-6">
        <div>Projected Annual Portfolio Return: <span className="font-mono text-5xl font-semibold tabular-nums tracking-tighter ml-3">{avgReturn.toFixed(1)}%</span></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {investments.map((inv, idx) => (
          <div key={idx} className="finance-card rounded-3xl p-7">
            <div className="flex justify-between">
              <div>
                <div className="font-semibold text-xl">{inv.name}</div>
                <div className="text-xs uppercase tracking-[1.5px] text-white/50 mt-px">{inv.risk} RISK</div>
              </div>
              <div className="text-right font-mono text-4xl tabular-nums tracking-[-1px] font-semibold">{inv.allocation}<span className="text-lg align-super text-white/40">%</span></div>
            </div>
            <div className="mt-5 text-[#22C55E] text-xl font-medium">+{inv.return}% YTD</div>
          </div>
        ))}
      </div>
    </div>
  );
};

const GoalsPage: React.FC<{ goals: Goal[]; setGoals: React.Dispatch<React.SetStateAction<Goal[]>> }> = ({ goals, setGoals }) => {
  const [newGoal, setNewGoal] = useState({ name: '', target: 5000 });

  const addGoal = () => {
    if (!newGoal.name) return;
    setGoals([...goals, { 
      id: Date.now(), 
      name: newGoal.name, 
      target: newGoal.target, 
      current: Math.floor(newGoal.target * 0.3), 
      deadline: "2026-01", 
      xp: 120 
    }]);
    setNewGoal({ name: '', target: 5000 });
  };

  const contribute = (id: number, amt: number) => {
    setGoals(goals.map(g => g.id === id ? { ...g, current: Math.min(g.target, g.current + amt) } : g));
  };

  const totalXP = goals.reduce((sum, g) => sum + g.xp, 0);

  return (
    <div className="ml-72 p-10 max-w-5xl">
      <div className="flex items-center justify-between mb-8">
        <div><h2 className="text-5xl tracking-[-2px] font-semibold">Gamified Goal Journey</h2><div className="text-white/50 mt-1">Level 14 • {totalXP} XP • 12 Achievements Unlocked</div></div>
        <div className="flex gap-3 items-center bg-[#121A2E] border border-white/10 rounded-3xl px-5 py-2 text-sm"><Award className="text-[#F59E0B]" /> 3 STREAK DAYS</div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-10">
        {goals.map(goal => {
          const progress = Math.min(Math.round((goal.current / goal.target) * 100), 100);
          const completed = progress === 100;
          return (
            <div key={goal.id} className="finance-card rounded-3xl p-9">
              <div className="flex justify-between mb-4">
                <div className="font-semibold text-2xl tracking-tight">{goal.name}</div>
                {completed && <div className="px-4 py-px text-xs font-medium rounded bg-emerald-500/10 text-emerald-400 self-start">COMPLETE</div>}
              </div>
              <div className="font-mono tabular-nums text-6xl tracking-[-3.6px] font-semibold mb-1">${goal.current}</div>
              <div className="text-white/50">of ${goal.target} • Due {goal.deadline}</div>

              <div className="my-8 h-3 bg-white/10 rounded-full overflow-hidden"><div className="progress-glow h-3 bg-gradient-to-r from-[#0A84FF] to-[#3B9EFF] rounded-full" style={{width: `${progress}%`}} /></div>

              <div className="flex gap-3">
                <button onClick={() => contribute(goal.id, 150)} className="flex-1 py-3.5 bg-white/5 hover:bg-white/10 active:bg-white/15 rounded-2xl text-sm font-medium">+ $150</button>
                <button onClick={() => contribute(goal.id, 500)} className="flex-1 py-3.5 bg-[#0A84FF] text-white rounded-2xl text-sm font-medium">+ $500</button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="finance-card p-9 rounded-3xl">
        <div className="font-medium mb-6">Create New Goal</div>
        <div className="flex gap-4">
          <input value={newGoal.name} onChange={e => setNewGoal({...newGoal, name: e.target.value})} placeholder="Goal name" className="flex-1 px-6 py-4 bg-black/30 rounded-2xl text-white placeholder:text-white/40 outline-none border border-white/10" />
          <input type="number" value={newGoal.target} onChange={e => setNewGoal({...newGoal, target: parseInt(e.target.value)})} className="w-44 px-6 py-4 bg-black/30 rounded-2xl text-white outline-none border border-white/10" />
          <button onClick={addGoal} className="px-9 bg-white text-black font-medium rounded-2xl flex items-center"><Plus className="mr-2" size={18} /> ADD GOAL</button>
        </div>
      </div>
    </div>
  );
};





// Onboarding Component - Professional Registration
const Onboarding: React.FC<{ onComplete: (profile: UserProfile) => void }> = ({ onComplete }) => {
  const [name, setName] = useState('');
  
  const handleStart = () => {
    if (name.trim().length < 2) return;
    const profile: UserProfile = {
      name: name.trim(),
      joinDate: new Date().toISOString().slice(0, 10)
    };
    onComplete(profile);
  };

  return (
    <div className="min-h-screen bg-[#0A0F1E] flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center">
        <div className="flex justify-center mb-8">
          <div className="w-14 h-14 bg-[#0A84FF] rounded-2xl flex items-center justify-center">
            <span className="text-white font-bold text-4xl tracking-[-3px]">A</span>
          </div>
        </div>
        
        <h1 className="text-6xl font-semibold tracking-[-3.2px] mb-3">AFP</h1>
        <p className="text-xl text-white/60 tracking-tight mb-12">Aether Finance Platform</p>

        <div className="finance-card rounded-3xl p-9 text-left">
          <div className="flex items-center gap-3 mb-6 text-[#0A84FF]">
            <User size={20} /> <span className="font-medium tracking-widest text-xs">NEW ACCOUNT</span>
          </div>
          
          <div className="mb-6">
            <div className="text-sm text-white/60 mb-2">YOUR FIRST NAME</div>
            <input 
              type="text" 
              value={name} 
              onChange={(e) => setName(e.target.value)} 
              placeholder="Enter your name" 
              className="w-full bg-black/40 border border-white/10 px-6 py-4 text-xl rounded-2xl focus:outline-none focus:border-[#0A84FF] placeholder:text-white/30"
              onKeyDown={(e) => e.key === 'Enter' && handleStart()}
            />
          </div>
          
          <button 
            onClick={handleStart} 
            disabled={name.trim().length < 2}
            className="w-full bg-[#0A84FF] disabled:bg-white/20 disabled:text-white/40 hover:bg-[#0070E6] py-4 rounded-2xl font-medium tracking-wide transition-all text-lg active:scale-[0.985]"
          >
            CREATE SECURE ACCOUNT
          </button>
          <div className="text-[10px] tracking-[1.5px] text-center text-white/40 mt-5">BANK-LEVEL ENCRYPTION • GDPR &amp; PSD2 COMPLIANT</div>
        </div>
      </div>
    </div>
  );
};

// Main App
function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [budgets, setBudgets] = useState<BudgetCategory[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);

  // Start fresh for every new registered user
  const handleRegister = (profile: UserProfile) => {
    setUser(profile);
    setBudgets([]); // Start completely zero
    setGoals([]);
    setInvestments([]);
    setTransactions([]);
  };

  // Dynamic Transaction System — updates budgets in real time
  const addTransaction = (category: string, amount: number) => {
    const newTx = { id: Date.now(), category, amount, date: new Date().toISOString().slice(0,10) };
    setTransactions(prev => [...prev, newTx]);

    setBudgets(prev => {
      const exists = prev.find(b => b.name === category);
      if (exists) {
        return prev.map(b => b.name === category ? { ...b, spent: b.spent + amount } : b);
      } else {
        return [...prev, { name: category, budget: 600, spent: amount }];
      }
    });
  };

  // Sidebar with personalized user name
  const Sidebar: React.FC = () => {
    const location = useLocation();
    if (!user) return null;

    const navItems = [
      { path: '/', label: 'Dashboard', icon: LayoutDashboard },
      { path: '/budget', label: 'Budget', icon: PieChart },
      { path: '/investments', label: 'Investments', icon: TrendingUp },
      { path: '/goals', label: 'Goals', icon: Target },
      { path: '/insights', label: 'AI Insights', icon: Zap },
      { path: '/security', label: 'Security', icon: Shield },
    ];

    return (
      <div className="w-72 bg-[#0A0F1E] border-r border-white/10 h-screen fixed left-0 top-0 z-50 flex flex-col">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-9 h-9 bg-[#0A84FF] rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-2xl tracking-[-1.5px]">A</span>
            </div>
            <div>
              <div className="font-semibold text-2xl tracking-[-1px]">AFP</div>
              <div className="text-[10px] text-white/50 -mt-1">AETHER FINANCE PLATFORM</div>
            </div>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path} className={`flex items-center gap-3.5 px-5 py-3.5 rounded-2xl text-sm font-medium transition-all ${isActive ? 'bg-white/10 text-white' : 'text-white/60 hover:text-white hover:bg-white/5'}`}>
                  <Icon size={19} /> {item.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-white/10">
          <div className="flex items-center gap-3 text-sm">
            <div className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center"><User size={17} /></div>
            <div>
              <div className="font-medium">{user.name}</div>
              <div className="text-[10px] text-white/50">Member since {user.joinDate}</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Dashboard (Zero-based until user adds data)
  const Dashboard = () => {
    const totalSpent = budgets.reduce((s, b) => s + b.spent, 0);
    const totalBudget = budgets.reduce((s, b) => s + b.budget, 0);
    const savingsRate = totalBudget > 0 ? Math.round(((totalBudget - totalSpent) / totalBudget) * 100) : 0;
    const progress = goals.length > 0 ? Math.round(goals.reduce((a, g) => a + (g.current / g.target), 0) / goals.length * 100) : 0;

    return (
      <div className="ml-72 p-10 max-w-6xl">
        <div className="mb-10">
          <div className="text-[#0A84FF] text-sm tracking-[3.5px] mb-2">PERSONAL ACCOUNT</div>
          <h1 className="text-6xl font-semibold tracking-[-3.2px]">Good to see you, {user?.name.split(' ')[0]}.</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-9">
          <div className="finance-card rounded-3xl p-8">
            <div className="text-white/60">Current Savings Rate</div>
            <div className="text-[72px] font-semibold tabular-nums tracking-[-5px] mt-1 leading-none">{savingsRate}<span className="text-5xl align-super">%</span></div>
          </div>
          <div className="finance-card rounded-3xl p-8">
            <div className="text-white/60">Active Goals Progress</div>
            <div className="text-[72px] font-semibold tabular-nums tracking-[-5px] mt-1 leading-none">{progress}<span className="text-5xl align-super">%</span></div>
            <div className="text-xs mt-3 text-white/50">{goals.length} goals tracked</div>
          </div>
          <div className="finance-card rounded-3xl p-8">
            <div className="text-white/60">Total Transactions Logged</div>
            <div className="text-[72px] font-semibold tabular-nums tracking-[-5px] mt-1 leading-none">{transactions.length}</div>
          </div>
        </div>

        <div className="finance-card rounded-3xl p-9">
          <div className="font-medium mb-4 flex items-center gap-2">Quick Actions — Start Building Your Profile</div>
          <div className="flex flex-wrap gap-3">
            <Link to="/budget" className="px-7 py-3 text-sm rounded-2xl border border-white/20 hover:bg-white/5 transition flex items-center gap-2"><Plus size={16}/> Add Budget Category</Link>
            <Link to="/goals" className="px-7 py-3 text-sm rounded-2xl border border-white/20 hover:bg-white/5 transition flex items-center gap-2"><Target size={16}/> Create Goal</Link>
            <Link to="/insights" className="px-7 py-3 text-sm rounded-2xl border border-white/20 hover:bg-white/5 transition flex items-center gap-2"><Zap size={16}/> View AI Insights</Link>
          </div>
        </div>
      </div>
    );
  };

  // Budget Page - Fully Dynamic
  const BudgetPage = () => (
    <div className="ml-72 p-10 max-w-4xl">
      <h2 className="text-5xl font-semibold tracking-[-2.4px]">Budget Management</h2>
      <p className="text-white/60 mt-2 mb-9">Add transactions to populate and update your personalized budget categories.</p>

      <div className="mb-8">
        <button onClick={() => {
          const cat = prompt("Category name (e.g. Groceries)");
          const amt = parseFloat(prompt("Amount spent?") || "0");
          if (cat && amt > 0) addTransaction(cat, amt);
        }} className="flex items-center gap-2 bg-[#0A84FF] hover:bg-[#0070E6] px-8 py-3.5 rounded-2xl text-sm font-medium">
          <Plus size={18} /> LOG NEW TRANSACTION
        </button>
      </div>

      {budgets.length === 0 && <div className="text-white/50 text-lg py-10">No budget categories yet. Add your first transaction to begin.</div>}

      {budgets.map((cat, idx) => {
        const pct = cat.budget ? Math.min(Math.round((cat.spent / cat.budget) * 100), 100) : 0;
        return (
          <div key={idx} className="finance-card rounded-3xl p-8 mb-4 flex justify-between items-center">
            <div>
              <div className="font-medium text-xl">{cat.name}</div>
              <div className="font-mono text-sm text-white/60 mt-px">${cat.spent} spent • Budget: ${cat.budget}</div>
            </div>
            <div className="text-right">
              <div className="font-mono text-3xl tracking-tight">{pct}%</div>
              <div className="h-px bg-white/10 mt-4 w-40"><div className="bg-[#0A84FF] h-px" style={{width: pct + "%"}} /></div>
            </div>
          </div>
        );
      })}
    </div>
  );

  // Investments
  const InvestmentsPage = () => {
    const avgReturn = investments.length ? investments.reduce((s, i) => s + i.return * i.allocation, 0) / 100 : 0;
    
    return (
      <div className="ml-72 p-10 max-w-5xl">
        <div className="flex justify-between items-end mb-9">
          <div><h2 className="text-5xl font-semibold tracking-[-2.4px]">Investment Portfolio</h2><p className="text-white/50 mt-2">Add allocations to start seeing AI recommendations</p></div>
          <button onClick={() => {
            const name = prompt("Investment name");
            if (!name) return;
            setInvestments([...investments, { id: Date.now(), name, allocation: 20, return: 9.5, risk: "Medium" }]);
          }} className="px-7 py-3 bg-white text-black rounded-2xl text-sm font-medium">ADD HOLDING</button>
        </div>

        {investments.length === 0 && <div className="text-white/50">Your portfolio is currently empty. Add your first investment holding.</div>}

        <div className="font-mono text-7xl tracking-[-4px] mb-9 font-semibold tabular-nums">{avgReturn.toFixed(1)}<span className="text-4xl align-super">%</span></div>

        {investments.map((inv, idx) => (
          <div key={idx} className="finance-card rounded-3xl px-9 py-8 mb-4 flex justify-between items-center">
            <div><div className="font-medium text-xl">{inv.name}</div><div className="text-xs text-white/50 mt-px">{inv.risk} RISK</div></div>
            <div className="text-right font-mono text-4xl tracking-tight tabular-nums">{inv.allocation}<span className="text-xl align-super text-white/30">%</span></div>
          </div>
        ))}
      </div>
    );
  };

  // Goals Page
  const GoalsPage = () => {
    const [goalName, setGoalName] = useState('');
    const [goalTarget, setGoalTarget] = useState(5000);

    const addNewGoal = () => {
      if (!goalName) return;
      setGoals([...goals, { id: Date.now(), name: goalName, target: goalTarget, current: 0, deadline: "2026-03", xp: 80 }]);
      setGoalName(''); setGoalTarget(5000);
    };

    const contribute = (id: number, amount: number) => {
      setGoals(goals.map(g => g.id === id ? { ...g, current: Math.min(g.target, g.current + amount) } : g));
    };

    return (
      <div className="ml-72 p-10 max-w-5xl">
        <h2 className="text-5xl font-semibold tracking-[-2.4px] mb-9">Financial Goals</h2>

        {goals.length === 0 && <div className="finance-card rounded-3xl p-10 text-white/60">No goals created yet. Define your first target to begin tracking progress.</div>}

        {goals.map(goal => {
          const pct = Math.min(Math.round((goal.current / goal.target) * 100), 100);
          return (
            <div key={goal.id} className="finance-card rounded-3xl px-9 py-8 mb-4">
              <div className="flex justify-between mb-4">
                <div className="font-medium text-2xl">{goal.name}</div>
                <div className="font-mono text-4xl tabular-nums tracking-tighter">${goal.current} <span className="text-lg text-white/30">/ {goal.target}</span></div>
              </div>
              <div className="h-1 bg-white/10 rounded"><div className="h-1 bg-[#0A84FF] rounded" style={{width: pct + "%"}} /></div>
              <div className="flex gap-3 mt-8">
                <button onClick={() => contribute(goal.id, 200)} className="flex-1 py-3 text-sm bg-white/5 hover:bg-white/10 rounded-2xl">+ $200</button>
                <button onClick={() => contribute(goal.id, 750)} className="flex-1 py-3 text-sm bg-[#0A84FF] rounded-2xl">+ $750</button>
              </div>
            </div>
          );
        })}

        <div className="finance-card p-9 mt-8 rounded-3xl">
          <div className="font-medium mb-5">Create Goal</div>
          <div className="flex gap-4">
            <input value={goalName} placeholder="Goal name" onChange={e => setGoalName(e.target.value)} className="flex-1 px-7 py-4 bg-black/40 border border-white/10 rounded-2xl" />
            <input type="number" value={goalTarget} onChange={e => setGoalTarget(+e.target.value)} className="w-40 px-7 py-4 bg-black/40 border border-white/10 rounded-2xl" />
            <button onClick={addNewGoal} className="px-9 bg-white text-black font-medium rounded-2xl">ADD GOAL</button>
          </div>
        </div>
      </div>
    );
  };

  const InsightsPage = () => {
    const [insights, setInsights] = useState<Insight[]>(() => generateAIInsights(budgets, goals));
    const refresh = () => setInsights(generateAIInsights(budgets, goals));

    return (
      <div className="ml-72 p-10 max-w-4xl">
        <div className="flex justify-between mb-9">
          <div><h2 className="text-5xl font-semibold tracking-[-2.4px]">AI Insights</h2><p className="text-white/50 mt-1">Generated from your personal data</p></div>
          <button onClick={refresh} className="px-8 py-3 text-sm bg-white/5 rounded-2xl">REFRESH ANALYSIS</button>
        </div>
        {insights.map(ins => (
          <div key={ins.id} className="finance-card rounded-3xl p-9 mb-4">
            <div className="font-semibold text-xl tracking-tight mb-2">{ins.title}</div>
            <div className="text-white/70 mb-6">{ins.description}</div>
            <div className="flex justify-between text-sm"><div className="text-[#22C55E] font-medium">{ins.impact}</div><div className="text-xs px-4 py-1 rounded bg-white/5">{ins.action}</div></div>
          </div>
        ))}
      </div>
    );
  };

  const SecurityPage = () => (
    <div className="ml-72 p-10 max-w-3xl">
      <h2 className="text-5xl tracking-[-2.4px] font-semibold mb-4">Security &amp; Compliance</h2>
      <div className="text-white/60">Bank-grade protection for every user account.</div>
      <div className="mt-10 space-y-4 text-sm">
        {["End-to-end 256-bit encryption", "Zero-knowledge architecture", "Real-time fraud monitoring", "Global regulatory compliance"].map((t, i) => (
          <div key={i} className="finance-card px-8 py-7 rounded-3xl flex gap-4"><Lock className="text-[#0A84FF] mt-px" />{t}</div>
        ))}
      </div>
    </div>
  );

  if (!user) {
    return <Onboarding onComplete={handleRegister} />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-[#0A0F1E] text-white overflow-hidden">
        <Sidebar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/budget" element={<BudgetPage />} />
          <Route path="/investments" element={<InvestmentsPage />} />
          <Route path="/goals" element={<GoalsPage />} />
          <Route path="/insights" element={<InsightsPage />} />
          <Route path="/security" element={<SecurityPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
